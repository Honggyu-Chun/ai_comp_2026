// file: src/local_path_selector.cpp

#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Point.h>
#include <std_msgs/Int32.h>
#include <std_msgs/String.h>

#include <katri_msgs/Objects.h>   // /obstacle_path_info (배열)

#include <vector>
#include <cmath>
#include <iostream>

class PathSelect
{
public:
    // Subscribers
    ros::Subscriber lane_path_sub_, local_path1_sub_, local_path2_sub_;
    ros::Subscriber current_path_sub_, state_sub_, sign_state_sub_;
    ros::Subscriber objects_sub_;  // katri_msgs/Objects

    // Publisher
    ros::Publisher selected_path_pub_;

    // Paths
    nav_msgs::Path local_path1_, local_path2_, lane_path_;

    // State/flags
    std::string frame_id_ = "base_link";
    std::string state, sign_state;
    int current_path_ = 1;
    int selected_path_number = 1;

    // Obstacle info (from katri_msgs/Objects)
    katri_msgs::Objects objects_msg_;
    bool obstacle = false;
    int obstacle_path_ = -1;
    double obstacle_distance_ = 1e9;

    // Simple pose (optional: 실제 odom/gps로 갱신 가능)
    geometry_msgs::Point current_pose_;

    // Params
    std::string objects_topic_ = "/obstacle_path_info";
    double obs_dist_threshold_ = 15.0;  // 전방 이 거리 이내면 회피

    PathSelect()
    {
        // private nh로 파라미터 로드
        ros::NodeHandle pnh("~");
        pnh.param("objects_topic",       objects_topic_,       objects_topic_);
        pnh.param("obs_dist_threshold",  obs_dist_threshold_,  obs_dist_threshold_);

        ros::NodeHandle nh;

        lane_path_sub_    = nh.subscribe("/lane_path",    10, &PathSelect::LanePathCB, this);
        local_path1_sub_  = nh.subscribe("/local_path1",  10, &PathSelect::LocalPath1CB, this);
        local_path2_sub_  = nh.subscribe("/local_path2",  10, &PathSelect::LocalPath2CB, this);
        current_path_sub_ = nh.subscribe("/current_path", 10, &PathSelect::CurrentPathCB, this);
        state_sub_        = nh.subscribe("/state",        10, &PathSelect::StateCB, this);
        sign_state_sub_   = nh.subscribe("/sign_state",   10, &PathSelect::SignStateCB, this);

        // katri_msgs/Objects 배열 구독
        objects_sub_      = nh.subscribe(objects_topic_,   10, &PathSelect::ObjectsCB, this);

        selected_path_pub_ = nh.advertise<nav_msgs::Path>("/selected_path", 1);
    }

    // --- Callbacks ---
    void LanePathCB(const nav_msgs::Path::ConstPtr &msg)   { lane_path_  = *msg; }
    void LocalPath1CB(const nav_msgs::Path::ConstPtr &msg) { local_path1_ = *msg; }
    void LocalPath2CB(const nav_msgs::Path::ConstPtr &msg) { local_path2_ = *msg; }
    void CurrentPathCB(const std_msgs::Int32::ConstPtr &msg){ current_path_ = msg->data; }
    void StateCB(const std_msgs::String::ConstPtr &msg)    { state = msg->data; }
    void SignStateCB(const std_msgs::String::ConstPtr &msg){ sign_state = msg->data; }

    void ObjectsCB(const katri_msgs::Objects::ConstPtr &msg)
    {
        objects_msg_ = *msg;
    }

    // --- Obstacle check using /obstacle_path_info (Objects 배열) ---
    void obstacle_check()
    {
        obstacle = false;
        obstacle_path_ = -1;
        obstacle_distance_ = 1e9;

        if (state != "static_obs") return;             // 정지장애물 상황에서만 회피
        if (objects_msg_.objects.empty()) return;

        // 같은 차선 + 전방(거리>0 또는 position=="front") + 임계거리 이내 중 가장 가까운 것 선택
        for (const auto& obj : objects_msg_.objects)
        {
            const bool same_lane = (obj.path_number == current_path_);
            const bool is_front  = (obj.distance > 0.0) || (obj.obj_position == "front");
            const bool within_th = (obj.distance > 0.0 && obj.distance <= obs_dist_threshold_);

            if (same_lane && is_front && within_th)
            {
                if (obj.distance < obstacle_distance_)
                {
                    obstacle = true;
                    obstacle_path_ = obj.path_number;
                    obstacle_distance_ = obj.distance;
                }
            }
        }

        // 디버그 출력(필요 시)
        // std::cout << "*****" << std::endl;
        // std::cout << "objects size: " << objects_msg_.objects.size() << std::endl;
        // std::cout << "current_path_: " << current_path_ << std::endl;
        // std::cout << "obstacle: " << std::boolalpha << obstacle
        //           << " path=" << obstacle_path_
        //           << " dist=" << obstacle_distance_ << std::endl;
        // std::cout << "*****" << std::endl;
    }

    // --- Publish helper ---
    void publishSelectedPath(nav_msgs::Path& path)
    {
        path.header.frame_id = frame_id_;
        path.header.stamp = ros::Time::now();
        selected_path_pub_.publish(path);
    }

    // --- Simple cubic interpolation to make a smooth lane change segment ---
    std::vector<geometry_msgs::PoseStamped> cubicInterpolatePath(const nav_msgs::Path &path, int num_points)
    {
        std::vector<geometry_msgs::PoseStamped> out;
        const double interpolate_length = 2.0;

        if (path.poses.empty()) {
            ROS_WARN_THROTTLE(1.0, "cubicInterpolatePath: empty path");
            return out;
        }

        int end_idx = -1;
        for (size_t i = 0; i < path.poses.size(); ++i)
        {
            double dx = path.poses[i].pose.position.x - current_pose_.x;
            if (dx >= interpolate_length) { end_idx = static_cast<int>(i); break; }
        }
        if (end_idx <= 0) {
            ROS_WARN_THROTTLE(1.0, "cubicInterpolatePath: too short path or no forward point");
            return out;
        }

        // start at (0,0) in base_link; end at end_idx point
        double x0 = 0.0, y0 = 0.0;
        double x1 = path.poses[end_idx].pose.position.x;
        double y1 = path.poses[end_idx].pose.position.y;

        double dx = x1 - x0; if (dx <= 0.0) dx = std::fabs(dx) + 1e-3;
        double end_slope = 0.0;
        if (end_idx + 1 < (int)path.poses.size())
        {
            double nx = path.poses[end_idx + 1].pose.position.x;
            double ny = path.poses[end_idx + 1].pose.position.y;
            double ndx = (nx - x1);
            end_slope = (std::fabs(ndx) > 1e-6) ? (ny - y1) / ndx : 0.0;
        }

        const double c0 = y0;
        const double c1 = 0.0; // start slope
        const double c2 = (3 * (y1 - y0) / (dx * dx)) - ((end_slope + 2 * c1) / dx);
        const double c3 = (2 * (y0 - y1) / (dx * dx * dx)) + ((end_slope + c1) / (dx * dx));

        out.reserve(num_points + (path.poses.size() - end_idx));
        for (int i = 0; i < num_points; ++i)
        {
            double t = (num_points == 1) ? 0.0 : (double)i / (num_points - 1);
            double x = x0 + t * dx;
            double y = c0 + c1 * (x - x0) + c2 * std::pow((x - x0), 2) + c3 * std::pow((x - x0), 3);

            geometry_msgs::PoseStamped p;
            p.header.frame_id = frame_id_;
            p.header.stamp = ros::Time::now();
            p.pose.position.x = x;
            p.pose.position.y = y;
            p.pose.orientation.w = 1.0;
            out.push_back(p);
        }
        for (size_t i = end_idx; i < path.poses.size(); ++i)
        {
            auto p = path.poses[i];
            p.header.frame_id = frame_id_;
            out.push_back(p);
        }
        return out;
    }

    // current_path 기준 반대 차선으로 스플라인 전환
    void lane_change(int current_path)
    {
        current_path_ = current_path;

        nav_msgs::Path path;
        int next_path = (current_path_ == 1) ? 2 :
                        (current_path_ == 2) ? 1 : -1;

        if (next_path == 1)
        {
            path.poses = cubicInterpolatePath(local_path1_, 10);
            selected_path_number = 1;
        }
        else if (next_path == 2)
        {
            path.poses = cubicInterpolatePath(local_path2_, 10);
            selected_path_number = 2;
        }
        else
        {
            ROS_WARN("lane_change: invalid current_path_: %d", current_path_);
            return;
        }
        publishSelectedPath(path);
    }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "local_path_selector");
    PathSelect ps;
    ros::Rate rate(20);

    while (ros::ok())
    {
        ros::spinOnce();

        // katri_msgs/Objects 기반 장애물 판단 (static_obs일 때만 의미)
        ps.obstacle_check();

        if (ps.state == "gps_fail")
        {
            ps.publishSelectedPath(ps.lane_path_);
        }
        else if (ps.state == "static_obs")
        {
            // 정지장애물 회피: 1번 차선 주행 중이면 2번으로 변경
            if (ps.obstacle)
            {
                if (ps.current_path_ == 1)
                {
                    ps.lane_change(1);   // 1 -> 2
                }
                else
                {
                    // 이미 2번이면 2번 경로 유지
                    ps.publishSelectedPath(ps.local_path2_);
                    ps.selected_path_number = 2;
                }
            }
            else
            {
                // 장애물 플래그 없으면 현재 차선 유지(보수적)
                if (ps.current_path_ == 2)
                {
                    ps.publishSelectedPath(ps.local_path2_);
                    ps.selected_path_number = 2;
                }
                else
                {
                    ps.publishSelectedPath(ps.local_path1_);
                    ps.selected_path_number = 1;
                }
            }
        }
        else if (ps.state == "go")
        {
            // go 복귀 시 2번이면 1번으로 되돌아오기
            if (ps.current_path_ == 2)
            {
                ps.lane_change(2); // 2 -> 1 복귀
            }
            else
            {
                ps.publishSelectedPath(ps.local_path1_);
                ps.selected_path_number = 1;
            }
        }
        else
        {
            // 기타 상태: 기본 1번 차선
            ps.publishSelectedPath(ps.local_path1_);
            ps.selected_path_number = 1;
        }

        // Debug print
        std::cout << "Current Path : " << ps.current_path_
                  << " | Selected Path : " << ps.selected_path_number << std::endl;
        std::cout << "Obstacle : " << std::boolalpha << ps.obstacle
                  << " (path=" << ps.obstacle_path_
                  << ", dist=" << ps.obstacle_distance_ << ")"
                  << " | State : " << ps.state << std::endl;
        std::cout << "=========================================== " << std::endl;

        rate.sleep();
    }
    return 0;
}
